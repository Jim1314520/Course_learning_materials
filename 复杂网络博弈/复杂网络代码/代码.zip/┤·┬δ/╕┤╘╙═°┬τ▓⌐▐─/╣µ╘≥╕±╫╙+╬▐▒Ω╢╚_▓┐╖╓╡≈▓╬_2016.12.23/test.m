
% lamda_Pc=[1 4 5 9;2 3 2 2; 4 5 6 6;1 2 3 4]
% step=0.2;
% lamda=1.2:step:1.8;
% Xname='t'; Yname='Pc' ;legd='lamda'%%x��Y�ᡢ��ǩ����
% 
% plotMultiCurve2(lamda_Pc,lamda,Xname,Yname,legd)

a=[];
for i=1:10
    a(i)=i+10;
end
b=repmat(a,[10,1]);