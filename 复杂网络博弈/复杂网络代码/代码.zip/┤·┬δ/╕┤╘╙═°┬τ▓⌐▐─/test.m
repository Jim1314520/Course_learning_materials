% tsg=[1 50 300];
% Ent1=[2 3 5 2;
%     2 1 4 5;
%     21 32 2 3]
% for i=1:300      
%     plotTSGragh(Ent1,tsg,i)
%     i
% end

MCount.lines('C:\Users\Administrator\Desktop\ComplexGame-finish-2016.12.26');