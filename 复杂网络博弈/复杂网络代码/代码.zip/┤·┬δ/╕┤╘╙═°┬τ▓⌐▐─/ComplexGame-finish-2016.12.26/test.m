
% lamda_Pc=[1 4 5 9;2 3 2 2; 4 5 6 6;1 2 3 4]
% step=0.2;
% lamda=1.2:step:1.8;
% Xname='t'; Yname='Pc' ;legd='lamda'%%x��Y�ᡢ��ǩ����
% 
% plotMultiCurve2(lamda_Pc,lamda,Xname,Yname,legd)

a=[0.1 0.2 0.3];b=[2 4 6];c=[0.2 0.4 0.6;0.4 0.8 1.2;0.6 1.2 1.8 ];
xname='a';yname='b';zname='c';tle='test';
plot3DGragh(a,b,c,xname,yname,zname,tle);
Xname='b'; Yname='c' ;legd='a'; %x��Y�ᡢ��ǩ����
plotMultiCurve(a,b,c,Xname,Yname,legd);