
% lamda_Pc=[1 4 5 9;2 3 2 2; 4 5 6 6;1 2 3 4]
% step=0.2;
% lamda=1.2:step:1.8;
% Xname='t'; Yname='Pc' ;legd='lamda'%%x��Y�ᡢ��ǩ����
% 
% plotMultiCurve2(lamda_Pc,lamda,Xname,Yname,legd)
% m=MCount.lines('C:\Users\Administrator\Desktop\ComplexGame-Grid+BAGame-2016.12.22') ;
% n=MCount.reallines('C:\Users\Administrator\Desktop\ComplexGame-Grid+BAGame-2016.12.22');
clear all;
clc;
A=[1 0 0 0;0 0 1 0;1 0 1 1;1 0 0 1];
B=find(A(3,:)==1);
